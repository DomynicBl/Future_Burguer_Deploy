package br.com.webevolui.ravi.desafio.ravi_desafio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
